entering point
